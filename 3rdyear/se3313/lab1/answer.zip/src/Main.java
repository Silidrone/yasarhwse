public class Main {
    public static void main(String[] args) {
        CargoCompany companyA = new CompanyA();
        CargoCompany companyB = new CompanyB();
        CargoCompany companyC = new CompanyC();

        companyA.printDeliveryInfo();
        companyB.printDeliveryInfo();
        companyC.printDeliveryInfo();
    }
}