public class ExpressDelivery implements DeliveryStrategy {

    @Override
    public void printDeliveryType() {
        System.out.println("Delivery type: ExpressDelivery");
    }

    @Override
    public int calculateDeliveryTime() {
        return 8;
    }
}
