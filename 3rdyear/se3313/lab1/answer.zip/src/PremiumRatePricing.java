public class PremiumRatePricing implements PricingStrategy {

    @Override
    public double calculateDeliveryPrice() {
        return 250;
    }
}
