public class CompanyA extends CargoCompany {

    CompanyA() {
        super(new ExpressDelivery(), new PremiumRatePricing());
    }
}
