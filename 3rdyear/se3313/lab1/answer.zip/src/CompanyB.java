public class CompanyB extends CargoCompany {
    CompanyB() {
       super(new StandardDelivery(), new FlatRatePricing());
    }
}
