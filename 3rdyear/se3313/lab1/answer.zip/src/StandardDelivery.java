public class StandardDelivery implements DeliveryStrategy {

    @Override
    public void printDeliveryType() {
        System.out.println("Delivery type: StandardDelivery");
    }

    @Override
    public int calculateDeliveryTime() {
        return 40;
    }
}
