public class CompanyC extends CargoCompany {
    CompanyC() {
        super(new ExpressDelivery(), new FlatRatePricing());
    }
}
