public interface PricingStrategy {
    double calculateDeliveryPrice(); //in dollars
}
