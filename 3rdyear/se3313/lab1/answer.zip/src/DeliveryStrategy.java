public interface DeliveryStrategy {
    void printDeliveryType();
    int calculateDeliveryTime(); //in hours
}
