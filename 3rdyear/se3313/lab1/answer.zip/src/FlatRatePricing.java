public class FlatRatePricing implements PricingStrategy {

    @Override
    public double calculateDeliveryPrice() {
        return 50;
    }
}
