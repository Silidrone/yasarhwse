public abstract class CargoCompany {
    DeliveryStrategy deliveryStrategy;
    PricingStrategy pricingStrategy;
    CargoCompany(DeliveryStrategy deliveryStrategy, PricingStrategy pricingStrategy) {
        this.deliveryStrategy = deliveryStrategy;
        this.pricingStrategy = pricingStrategy;
    }

    void setDeliveryStrategy(DeliveryStrategy deliveryStrategy) {
        this.deliveryStrategy = deliveryStrategy;
    }

    void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    void printDeliveryInfo() {
        System.out.println("-------------------");
        deliveryStrategy.printDeliveryType();
        System.out.println("Delivery due time in hours: " + deliveryStrategy.calculateDeliveryTime());
        System.out.println("Delivery price $" + pricingStrategy.calculateDeliveryPrice());
        System.out.println("-------------------");
    }
}
