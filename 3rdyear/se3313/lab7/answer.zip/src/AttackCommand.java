public class AttackCommand extends Command {
    AttackCommand(GameCharacter gc) {
        super(gc);
    }

    public void execute() {
        gameCharacter.attack();
    }
}
