public class MoveLeftCommand extends Command {
    MoveLeftCommand(GameCharacter gc) {
        super(gc);
    }

    public void execute() {
        gameCharacter.left();
    }
}
