public class MoveUpCommand extends Command{
    MoveUpCommand(GameCharacter gc) {
        super(gc);
    }

    public void execute() {
        gameCharacter.up();
    }
}
