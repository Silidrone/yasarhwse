public abstract class Command {
    protected GameCharacter gameCharacter;

    Command(GameCharacter gc) {
        gameCharacter = gc;
    }
    abstract void execute();
}
