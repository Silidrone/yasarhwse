public class JumpCommand extends Command{
    JumpCommand(GameCharacter gc) {
        super(gc);
    }

    public void execute() {
        gameCharacter.jump();
    }
}
