public class GameController {
    Command currentCommand = null;

    void setCommand(Command c) {
        currentCommand = c;
    }

    void performCommand() {
        if(currentCommand != null) {
            currentCommand.execute();
        }
    }
}
