import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        GameCharacter gameCharacter = new GameCharacter();
        GameController gameController = new GameController();

        System.out.println("– ’w’: Move Up\n" +
                "– ’a’: Move Left\n" +
                "– ’s’: Move Down\n" +
                "– ’d’: Move Right\n" +
                "– ’j’: Jump\n" +
                "– ’k’: Attack\n" +
                "– ’q’: Quit");
        boolean quit = false;
        while(!quit) {
            String c = s.next();
            if(Objects.equals(c, "w")) {
                gameController.setCommand(new MoveUpCommand(gameCharacter));
            } else if(Objects.equals(c, "a")) {
                gameController.setCommand(new MoveLeftCommand(gameCharacter));
            } else if(Objects.equals(c, "s")) {
                gameController.setCommand(new MoveDownCommand(gameCharacter));
            } else if(Objects.equals(c, "d")) {
                gameController.setCommand(new MoveRightCommand(gameCharacter));
            } else if(Objects.equals(c, "j")) {
                gameController.setCommand(new JumpCommand(gameCharacter));
            } else if(Objects.equals(c, "k")) {
                gameController.setCommand(new AttackCommand(gameCharacter));
            } else if(Objects.equals(c, "q")) {
                quit = true;
            }

            gameController.performCommand();
        }
        System.out.println("Game exited!");
    }
}