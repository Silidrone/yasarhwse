public class MoveDownCommand extends Command {
    MoveDownCommand(GameCharacter gc) {
        super(gc);
    }

    public void execute() {
        gameCharacter.down();
    }
}
