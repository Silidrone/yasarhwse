public class MoveRightCommand extends Command {
    MoveRightCommand(GameCharacter gc) {
        super(gc);
    }

    public void execute() {
        gameCharacter.right();
    }
}
