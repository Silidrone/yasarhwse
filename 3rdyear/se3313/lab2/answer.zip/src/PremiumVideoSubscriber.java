public class PremiumVideoSubscriber extends VideoStreamingSubscriber {
    PremiumVideoSubscriber(String name) {
        super(name);
    }

    @Override
    public void update(String videoServiceName) {
        System.out.println("Wake up " + this.name + "! " + videoServiceName + " uploaded a new video without ads!");
    }
}
