public class MinutePhysics extends VideoStreamingService {
    MinutePhysics() {
        super("Minute Physics");
    }
}
