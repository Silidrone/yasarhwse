public interface Observer {
    void update(String videoServiceName);
}
