public class StandardVideoSubscriber extends VideoStreamingSubscriber {
    StandardVideoSubscriber(String name) {
        super(name);
    }
    @Override
    public void update(String videoServiceName) {
        System.out.println("Wake up " + this.name + "! " + videoServiceName + " uploaded a new video!");
    }
}
