// Muhamed Cicak 21070006208

public class Main {
    public static void main(String[] args) {
        Subject veritasium = new Veritasium();
        Subject minutePhysics = new MinutePhysics();
        Observer elena = new StandardVideoSubscriber("Elena");
        Observer derek = new PremiumVideoSubscriber("Derek");
        veritasium.registerObserver(elena);
        minutePhysics.registerObserver(derek);
        veritasium.notifyObservers();
        minutePhysics.notifyObservers();
        veritasium.removeObserver(elena);
        veritasium.notifyObservers();
    }
}