public abstract class VideoStreamingSubscriber implements Observer {
    String name;
    VideoStreamingSubscriber(String name) {
        this.name = name;
    }
}
