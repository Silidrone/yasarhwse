public class Veritasium extends VideoStreamingService {
    Veritasium() {
        super("Veritasium");
    }
}
