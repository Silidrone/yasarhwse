import java.util.ArrayList;

public abstract class VideoStreamingService implements Subject {
    ArrayList<Observer> observers = new ArrayList<>();
    String name;

    VideoStreamingService(String name) {
        this.name = name;
    }
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    public void notifyObservers() {
        for(Observer observer : observers) {
            observer.update(name);
        }
    }
}
