public class RenaultSUV extends Renault {
    RenaultSUV() {
        super("RenaultSUV", 4200, 11, 110, 47000);
    }
}
