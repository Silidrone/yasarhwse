public class ToyotaHatchback extends Toyota {
    ToyotaHatchback() {
        super("ToyotaHatchback", 1200, 50, 300, 15000);
    }
}
