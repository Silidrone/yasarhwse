public abstract class Car {
    protected String modelName;
    protected double weight;
    protected double acceleration;
    protected double topSpeed;
    protected double price;

    Car(String modelName, double weight, double acceleration, double topSpeed, double price) {
        this.modelName = modelName;
        this.weight = weight;
        this.acceleration = acceleration;
        this.topSpeed = topSpeed;
        this.price = price;
    }

    public void displayCarSpecs() {
        System.out.println(modelName + " car specs: (weight: " + weight + ", acceleration: " + acceleration + ", topSpeed: " + topSpeed + ", price: " + price + ")");
    }
    public double getDeliveryTime() {
        return weight * 3 / acceleration;
    }
    public double getProductionTime() {
        return weight * Math.log(price) * Math.log(topSpeed);
    }
    public abstract String getOrigin();
}
