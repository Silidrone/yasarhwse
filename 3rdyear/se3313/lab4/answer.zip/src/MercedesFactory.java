import java.util.Objects;

public class MercedesFactory extends CarFactory {
    public Car constructCar(String bodyType) {
        boolean sedan = Objects.equals(bodyType, "Sedan");
        boolean hatchback = Objects.equals(bodyType, "Hatchback");
        boolean SUV = Objects.equals(bodyType, "SUV");

        if(sedan) {
            return new MercedesSedan();
        } else if(hatchback) {
            return new MercedesHatchback();
        } else if(SUV) {
            return new MercedesSUV();
        }

        return null;
    }
}
