public class MercedesSedan extends Mercedes {
    MercedesSedan() {
        super("MercedesSedan", 2000, 20, 150, 50000);
    }
}
