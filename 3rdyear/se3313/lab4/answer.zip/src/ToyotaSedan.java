public class ToyotaSedan extends Toyota {
    ToyotaSedan() {
        super("ToyotaSedan", 2000, 40, 190, 40000);
    }
}
