// Muhamed Cicak 21070006208

import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.println("Enter car brand: ");
        String brand = s.nextLine();

        CarFactory carFactory;

        if(Objects.equals(brand, "Toyota")) {
            carFactory = new ToyotaFactory();
        } else if(Objects.equals(brand, "Mercedes")) {
            carFactory = new MercedesFactory();
        } else if(Objects.equals(brand, "Renault")) {
            carFactory = new RenaultFactory();
        } else {
            carFactory = null;
            System.out.println("That car brand is unavailable!");
            return;
        }

        System.out.println("Enter body type: ");
        String bodyType = s.nextLine();

        Car c = carFactory.constructCar(bodyType);
        if(c == null) {
            System.out.println("That body type is unavailable!");
            return;
        }

        c.displayCarSpecs();
        System.out.println("ETA Production Time: " + c.getProductionTime() + " hours");
        System.out.println("ETA Delivery Time: " + c.getDeliveryTime() + " hours");
    }
}