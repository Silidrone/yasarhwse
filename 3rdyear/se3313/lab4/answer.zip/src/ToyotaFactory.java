import java.util.Objects;

public class ToyotaFactory extends CarFactory {
    public Car constructCar(String bodyType) {
        boolean sedan = Objects.equals(bodyType, "Sedan");
        boolean hatchback = Objects.equals(bodyType, "Hatchback");
        boolean SUV = Objects.equals(bodyType, "SUV");

        if(sedan) {
            return new ToyotaSedan();
        } else if(hatchback) {
            return new ToyotaHatchback();
        } else if(SUV) {
            return new ToyotaSUV();
        }

        return null;
    }
}
