public abstract class Mercedes extends Car {
    Mercedes(String modelName, double weight, double acceleration, double topSpeed, double price) {
        super(modelName, weight, acceleration, topSpeed, price);
    }
    public String getOrigin() {
        return "Germany";
    }
}
