public class ToyotaSUV extends Toyota {
    ToyotaSUV() {
        super("ToyotaSUV", 8200, 30, 170, 38000);
    }
}
