public abstract class CarFactory {
    public abstract Car constructCar(String bodyType);
}
