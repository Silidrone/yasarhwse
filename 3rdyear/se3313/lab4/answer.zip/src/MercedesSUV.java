public class MercedesSUV extends Mercedes {
    MercedesSUV() {
        super("MercedesSUV", 4000, 10, 100, 45000);
    }
}
