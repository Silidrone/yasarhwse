public abstract class Toyota extends Car {
    Toyota(String modelName, double weight, double acceleration, double topSpeed, double price) {
        super(modelName, weight, acceleration, topSpeed, price);
    }
    public String getOrigin() {
        return "Japan";
    }
}
