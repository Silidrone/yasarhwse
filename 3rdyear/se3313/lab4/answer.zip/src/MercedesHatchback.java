public class MercedesHatchback extends Mercedes {
    MercedesHatchback() {
        super("MercedesHatchback", 1000, 30, 200, 40000);
    }
}
