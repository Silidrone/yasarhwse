public class RenaultHatchback extends Renault {
    RenaultHatchback() {
        super("RenaultHatchback", 900, 27, 180, 20000);
    }
}
