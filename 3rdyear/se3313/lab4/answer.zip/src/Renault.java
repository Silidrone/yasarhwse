public abstract class Renault extends Car {
    Renault(String modelName, double weight, double acceleration, double topSpeed, double price) {
        super(modelName, weight, acceleration, topSpeed, price);
    }
    public String getOrigin() {
        return "France";
    }
}
