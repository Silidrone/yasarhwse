import java.util.Objects;

public class RenaultFactory extends CarFactory{
    public Car constructCar(String bodyType) {
        boolean sedan = Objects.equals(bodyType, "Sedan");
        boolean hatchback = Objects.equals(bodyType, "Hatchback");
        boolean SUV = Objects.equals(bodyType, "SUV");

        if(sedan) {
            return new RenaultSedan();
        } else if(hatchback) {
            return new RenaultHatchback();
        } else if(SUV) {
            return new RenaultSUV();
        }

        return null;
    }
}
