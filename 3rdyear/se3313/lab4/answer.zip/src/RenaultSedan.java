public class RenaultSedan extends Renault {
    RenaultSedan() {
        super("RenaultSedan", 1800, 18, 130, 43000);
    }
}
