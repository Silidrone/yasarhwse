class InsuranceSystem {
    public void purchaseInsurance(String destinationCity, String startDate, String endDate) {
        System.out.println("Travel insurance purchased for the trip to " + destinationCity +
                " from " + startDate + " to " + endDate);
    }
}