class ActivityBookingSystem {
    public void bookActivity(String destinationCity, String activityName, String activityDate) {
        System.out.println("Activity booked in " + destinationCity + ":" + activityName + " on " + activityDate);
    }
}