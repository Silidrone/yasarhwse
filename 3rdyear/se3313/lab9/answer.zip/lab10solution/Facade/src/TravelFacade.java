class TravelFacade {
    private FlightBookingSystem flightBookingSystem;
    private HotelReservationSystem hotelReservationSystem;
    private CarRentalSystem carRentalSystem;
    private ActivityBookingSystem activityBookingSystem;
    private InsuranceSystem insuranceSystem;
    private NotificationService notificationService;

    public TravelFacade() {
        this.flightBookingSystem = new FlightBookingSystem();
        this.hotelReservationSystem = new HotelReservationSystem();
        this.carRentalSystem = new CarRentalSystem();
        this.activityBookingSystem = new ActivityBookingSystem();
        this.insuranceSystem = new InsuranceSystem();
        this.notificationService = new NotificationService();
    }
    public void bookFlight(String departureCity, String destinationCity, String departureDate) {
        flightBookingSystem.bookFlight(departureCity, destinationCity, departureDate);
    }
    public void reserveHotel(String city, String checkInDate, String checkOutDate) {
        hotelReservationSystem.reserveHotel(city, checkInDate, checkOutDate);
    }
    public void rentCar(String city, String startDate, int numberOfDays) {
        carRentalSystem.rentCar(city, startDate, numberOfDays);
    }
    public void bookActivity(String destinationCity, String activityName, String activityDate) {
        activityBookingSystem.bookActivity(destinationCity, activityName, activityDate);
    }

    public void purchaseInsurance(String destinationCity, String startDate, String endDate) {
        insuranceSystem.purchaseInsurance(destinationCity, startDate, endDate);
    }
    public void notifyUser() {
        notificationService.notifyUser("Notification: Your trip is booked successfully!");
    }
}