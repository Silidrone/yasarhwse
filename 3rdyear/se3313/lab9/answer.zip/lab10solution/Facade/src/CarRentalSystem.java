class CarRentalSystem {
    public void rentCar(String city, String startDate, int numberOfDays) {
        System.out.println("Car rented in " + city + " starting from " + startDate + " for " + numberOfDays + " days");
    }
}