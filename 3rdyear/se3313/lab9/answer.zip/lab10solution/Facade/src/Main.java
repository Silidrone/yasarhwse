public class Main {
    public static void main(String[] args) {
        TravelFacade travelFacade = new TravelFacade();

        travelFacade.bookFlight("Izmir", "Istanbul", "2023-12-11");
        travelFacade.reserveHotel("Istanbul", "2023-12-11", "2023-12-17");
        travelFacade.rentCar("Istanbul", "2023-12-11", 6);
        travelFacade.bookActivity("Istanbul", "Sightseeing Tour", "2023-12-15");
        travelFacade.purchaseInsurance("Istanbul", "2023-12-11", "2023-12-17");
        travelFacade.notifyUser();
    }
}
