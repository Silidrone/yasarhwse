public class MovingDownState implements ElevatorState{
    public void pressButton(Elevator elevator, int destinationFloor) {
        int currentFloor = elevator.getCurrentFloor();
        elevator.setCurrentFloor(destinationFloor);
        if(destinationFloor < currentFloor) {
            System.out.println("Moving down to floor " + destinationFloor);
            elevator.setCurrentState(new StationaryState());
        } else {
            System.out.println("Move down operation can only be done to a floor located lower!");
        }
    }
}
