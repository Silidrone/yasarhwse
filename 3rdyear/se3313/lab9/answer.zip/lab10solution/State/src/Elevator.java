public class Elevator {
    ElevatorState currentState = new StationaryState();
    int currentFloor = 0;
    public void setCurrentState(ElevatorState s) {
        currentState = s;
    }

    public void setCurrentFloor(int floor) {
        currentFloor = floor;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    void moveToFloor(int destinationFloor) {
        currentState.pressButton(this, destinationFloor);
    }
}
