public class StationaryState implements ElevatorState {
    public void pressButton(Elevator elevator, int destinationFloor) {
        int currentFloor = elevator.getCurrentFloor();
        elevator.setCurrentFloor(destinationFloor);
        if (destinationFloor == currentFloor) {
            System.out.println("The elevator will stay on the same floor!");
            return;
        }
        if (destinationFloor > currentFloor) {
            System.out.println("Moving up to floor " + destinationFloor);
            elevator.setCurrentState(new MovingUpState());
        } else if (destinationFloor < currentFloor) {
            System.out.println("Moving down to floor " + destinationFloor);
            elevator.setCurrentState(new MovingDownState());
        }
    }
}
