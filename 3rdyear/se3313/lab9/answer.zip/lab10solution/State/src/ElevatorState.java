public interface ElevatorState {
    void pressButton(Elevator elevator, int destinationFloor);
}
