public class ElevatorSystemExample {
    public static void main(String[] args) {
        Elevator e = new Elevator();
        e.moveToFloor(3);
        e.moveToFloor(5);
        e.moveToFloor(2);
    }
}