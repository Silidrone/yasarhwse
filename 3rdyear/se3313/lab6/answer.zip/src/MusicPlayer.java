import java.util.ArrayList;
import java.util.List;

public class MusicPlayer {
    private List<String> playlist;

    private static MusicPlayer instance;
    private MusicPlayer() {
        this.playlist = new ArrayList<>();
    }

    public static MusicPlayer getInstance() {
        if (instance == null) {
            instance = new MusicPlayer();
        }
        return instance;
    }
    public void playMP3() {
        System.out.println("Playing MP3!");
    }

    public void playFLAC() {
        System.out.println("Playing FLAC!");
    }

    public void playAAC() {
        System.out.println("Playing AAC!");
    }

    public void addToPlaylist(String song) {
        System.out.println("Adding to playlist: " + song);
        this.playlist.add(song);
    }

    public void removeFromPlaylist(int index) {
        if (index >= 0 && index < playlist.size()) {
            System.out.println("Removing from playlist: " + playlist.get(index));
            this.playlist.remove(index);
        } else {
            System.out.println("Invalid index");
        }
    }

    public void showPlaylist() {
        System.out.println("Playlist:");
        for (int i = 0; i < playlist.size(); i++) {
            System.out.println("[" + i + "] " + playlist.get(i));
        }
    }

    public boolean authenticateUser(String username, String password) {
        String correctPassword = "supersecret";
        return password.equals(correctPassword);
    }

    public void logEvent() {
        System.out.println("Log event");
    }
}
