import java.util.Scanner;

public class MusicPlayerMenu {
    private MusicPlayer musicPlayer;
    private Scanner scanner;

    public MusicPlayerMenu() {
        this.musicPlayer = MusicPlayer.getInstance();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        int choice;
        do {
            System.out.println("1. Play MP3");
            System.out.println("2. Play FLAC");
            System.out.println("3. Play AAC");
            System.out.println("4. Add to playlist");
            System.out.println("5. Remove from playlist");
            System.out.println("6. Show playlists");
            System.out.println("7. Authenticate user");
            System.out.println("8. Log Event");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    musicPlayer.playMP3();
                    break;
                case 2:
                    musicPlayer.playFLAC();
                    break;
                case 3:
                    musicPlayer.playAAC();
                    break;
                case 4:
                    System.out.print("Enter the song to add to the playlist: ");
                    String songToAdd = scanner.next();
                    musicPlayer.addToPlaylist(songToAdd);
                    break;
                case 5:
                    System.out.print("Enter the index to remove from the playlist: ");
                    int indexToRemove = scanner.nextInt();
                    musicPlayer.removeFromPlaylist(indexToRemove);
                    break;
                case 6:
                    musicPlayer.showPlaylist();
                    break;
                case 7:
                    System.out.print("Enter username: ");
                    String username = scanner.next();
                    System.out.print("Enter password: ");
                    String password = scanner.next();
                    boolean authenticated = musicPlayer.authenticateUser(username, password);
                    System.out.println("Authentication " + (authenticated ? "successful" : "failed"));
                    break;
                case 8:
                    musicPlayer.logEvent();
                    break;
            }
        } while (choice != 0);
    }
}