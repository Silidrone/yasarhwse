// MUHAMED CICAK 21070006208

public class Main {
    public static void main(String[] args) {
        MusicPlayerMenu menu = new MusicPlayerMenu();
        menu.start();
    }
}