import java.util.Objects;

public class VehicleClient {
    Vehicle createCar(String carType, String engineType) {
        Vehicle v = null;

        if(Objects.equals(carType, "Car")) {
            v = new Car();
        } else if (Objects.equals(carType, "Motorcycle")) {
            v = new Motorcycle();
        }

        Engine e = null;
        if(Objects.equals(engineType, "Gasoline")) {
            e = new GasolineEngine();
        } else if(Objects.equals(engineType, "Electric")) {
            e = new ElectricEngine();
        }

        if(v == null || e == null) return null;

        v.setEngine(e);

        return v;
    }
}
