public class GasolineEngine implements Engine {
    @Override
    public void start() {
        System.out.println("Gasoline Engine starting!");
    }

    @Override
    public void stop() {
        System.out.println("Gasoline Engine stopping!");
    }
}
