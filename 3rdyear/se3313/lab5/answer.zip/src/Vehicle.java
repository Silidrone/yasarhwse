public abstract class Vehicle {
    protected Engine engine;

    public void setEngine(Engine e) {
        engine = e;
    }

    public abstract void startEngine();
    public abstract void stopEngine();
}
