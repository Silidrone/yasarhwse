public interface Engine {
    void start();
    void stop();
}
