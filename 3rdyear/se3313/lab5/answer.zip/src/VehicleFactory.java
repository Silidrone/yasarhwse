import java.util.Objects;

public abstract class VehicleFactory {
    public abstract Vehicle createVehicle();
    public Engine createEngine(String type) {
        if(Objects.equals(type, "Electric")) {
            return new ElectricEngine();
        } else if(Objects.equals(type, "Gasoline")) {
            return new GasolineEngine();
        }
        return null;
    }
}
