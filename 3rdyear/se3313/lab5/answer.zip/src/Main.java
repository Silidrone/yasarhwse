public class Main {
    public static void main(String[] args) {
        VehicleFactory carFactory = new CarFactory();
        Vehicle car = carFactory.createVehicle();
        Engine carEngine = carFactory.createEngine("Gasoline");

        car.setEngine(carEngine);

        car.startEngine();
        carEngine.start();

        VehicleFactory motorcycleFactory = new MotorcycleFactory();
        Vehicle motorcycle = motorcycleFactory.createVehicle();
        Engine motorycycleEngine = motorcycleFactory.createEngine("Electric");

        motorcycle.setEngine(motorycycleEngine);

        motorcycle.startEngine();
        motorycycleEngine.start();

        VehicleClient vehicleClient = new VehicleClient();
        Vehicle gasolineMotorcycle = vehicleClient.createCar("Motorcycle", "Gasoline");
        gasolineMotorcycle.startEngine();
        gasolineMotorcycle.stopEngine();
    }
}