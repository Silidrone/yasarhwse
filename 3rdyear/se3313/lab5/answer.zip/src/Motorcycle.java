public class Motorcycle extends Vehicle {
    @Override
    public void startEngine() {
        System.out.println("Motorcycle engine starting!");
        engine.start();
    }

    @Override
    public void stopEngine() {
        System.out.println("Motorcycle engine stopping!");
        engine.stop();
    }
}
