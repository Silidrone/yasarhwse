public interface ViewObserver {
    void update(int totalCount);
}
