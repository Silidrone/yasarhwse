public interface TextVerifier {
    boolean verify(String str);
}
