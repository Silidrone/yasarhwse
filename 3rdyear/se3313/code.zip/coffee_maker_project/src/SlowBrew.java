public class SlowBrew extends BrewBehavior{
    @Override
    protected int brewTime() {
        return 6000;
    }
}
