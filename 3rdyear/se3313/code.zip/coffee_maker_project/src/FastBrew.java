public class FastBrew extends BrewBehavior{
    @Override
    protected int brewTime() {
        return 2000;
    }
}
