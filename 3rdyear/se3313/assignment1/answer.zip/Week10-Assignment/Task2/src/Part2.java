// Muhamed Cicak 21070006208
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class Part2 {
    public static void main(String[] args) {
        ArrayList<Integer> A = new ArrayList<>();

        HashMap<String, Integer> M = new HashMap<>();
        M.put("k1", 1);
        M.put("k2", 2);
        M.put("k3", 3);
        M.put("k4", 4);
        M.put("k5", 5);

        Iterator<Map.Entry<String, Integer>> iterator = M.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            A.add(entry.getValue());
        }

        Iterator<Integer> AIterator = A.iterator();
        System.out.println("Elements in ArrayList A:");

        while (AIterator.hasNext()) {
            System.out.println(AIterator.next());
        }
    }
}
