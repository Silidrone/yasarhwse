import java.util.Random;

public class HasQuarterGumballState implements GumballState {
    Random randomWinner = new Random(System.currentTimeMillis());
    public void insertQuarter(GumballMachine m) {
        System.out.println("You can't insert another quarter");
    }

    public void ejectQuarter(GumballMachine m) {
        System.out.println("Quarter returned");
        m.setState(new NoQuarterGumballState());
    }

    public void turnCrank(GumballMachine m) {
        System.out.println("You turned...");
        int winner = randomWinner.nextInt(1);
        if((winner == 0) && (m.getGumballCount() > 1)) {
            m.setState(new WinnerGumballState());
        } else {
            m.setState(new SoldGumballState());
        }
    }

    public void dispense(GumballMachine m) {
        System.out.println("No gumball dispensed");
    }
}
