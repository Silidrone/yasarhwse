public class NoQuarterGumballState implements GumballState {
    public void insertQuarter(GumballMachine m) {
        System.out.println("You inserted a quarter");
        m.setState(new HasQuarterGumballState());
    }

    public void ejectQuarter(GumballMachine m) {
        System.out.println("You haven't inserted a quarter");
    }

    public void turnCrank(GumballMachine m) {
        System.out.println("You turned, but there's no quarter");
    }

    public void dispense(GumballMachine m) {
        System.out.println("You need to pay first");
    }
}
