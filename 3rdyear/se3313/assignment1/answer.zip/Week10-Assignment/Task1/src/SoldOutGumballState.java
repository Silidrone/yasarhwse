public class SoldOutGumballState implements GumballState {
    public void insertQuarter(GumballMachine m) {
        System.out.println("There are no gumballs left, don't insert any quarters!");
    }

    public void ejectQuarter(GumballMachine m) {
        System.out.println("There is no quarter to eject!");
    }

    public void turnCrank(GumballMachine m) {
        System.out.println("There is no quarter to turn the crank!");
    }

    public void dispense(GumballMachine m) {
        System.out.println("There are no gumballs to dispense!");
    }
}
