public class GumballMachine {
    private GumballState currentState;
    private int gumballCount;

    public GumballMachine(int numberOfGumballs) {
        this.gumballCount = numberOfGumballs;
        if (gumballCount > 0) {
            currentState = new NoQuarterGumballState();
        } else {
            currentState = new SoldOutGumballState();
        }
    }

    public void insertQuarter() {
        currentState.insertQuarter(this);
    }

    public void ejectQuarter() {
        currentState.ejectQuarter(this);
    }

    public void turnCrank() {
        currentState.turnCrank(this);
        currentState.dispense(this);
    }

    public void releaseBall() {
        System.out.println("A gumball comes rolling out the slot...");
        if(gumballCount != 0) {
            gumballCount -= 1;
        }
    }

    public void setState(GumballState s) {
        currentState = s;
    }

    public int getGumballCount() {
        return gumballCount;
    }

    public String toString() {
        String r = "";
        r += "Mighty Gumball, Inc.\nJava-enabled Standing Gumball Model #2004\nInventory: " + gumballCount + "\n";
        switch (currentState) {
            case NoQuarterGumballState noQuarterGumballState -> r += "Machine is waiting for a quarter";
            case SoldOutGumballState soldOutGumballState -> r += "Machine is sold out";
            case SoldGumballState soldGumballState -> r += "Machine is dispensing a sold gumball";
            case HasQuarterGumballState hasQuarterGumballState -> r += "Machine is waiting for it's crank to be turned";
            case WinnerGumballState winnerGumballState ->
                    r += "Machine is dispensing a sold gumball for the 1/10 winner!";
            case null, default ->
                    r += "Machine is in an unknown state, don't use it! Please contact the administrator!";
        }

        return r + "\n";
    }
}
