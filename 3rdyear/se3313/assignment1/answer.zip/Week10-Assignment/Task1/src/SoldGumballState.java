public class SoldGumballState implements GumballState {
    public void insertQuarter(GumballMachine m) {
        System.out.println("Please wait, we're already giving you a gumball");
    }

    public void ejectQuarter(GumballMachine m) {
        System.out.println("Sorry, you already turned the crank");
    }

    public void turnCrank(GumballMachine m) {
        System.out.println("Turning twice doesn't get you another gumball!");
    }

    public void dispense(GumballMachine m) {
        m.releaseBall();
        if(m.getGumballCount() > 0) {
            m.setState(new NoQuarterGumballState());
        } else {
            m.setState(new SoldOutGumballState());
        }
    }
}
