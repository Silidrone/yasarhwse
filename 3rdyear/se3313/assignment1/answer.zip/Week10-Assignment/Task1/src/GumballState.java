public interface GumballState {
    void insertQuarter(GumballMachine m);

    void ejectQuarter(GumballMachine m);

    void turnCrank(GumballMachine m);

    void dispense(GumballMachine m);
}
