public interface Service {
    void readDataFile(String filePath);
}
