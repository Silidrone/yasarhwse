public class Main {
    public static void main(String[] args) {
        FileReader txtReader = new TxtReader();
        txtReader.readFile("./src/test.txt");
        FileReader adapter1 = new ServiceAdapter(new ExcelReader());
        adapter1.readFile("./src/test1.xls");
        FileReader adapter2 = new ServiceAdapter(new JSONReader());
        adapter2.readFile("./src/test.json");
    }
}