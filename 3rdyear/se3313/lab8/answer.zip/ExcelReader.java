import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;
public class ExcelReader implements Service {
    public void readDataFile(String filePath) {
        try {
            FileInputStream file = new FileInputStream(filePath);
            Workbook workbook = new HSSFWorkbook(file);
            StringBuilder excelContent = new StringBuilder();

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                for (Cell cell : row) {
                    switch (cell.getCellType()) {
                        case STRING:
                            excelContent.append(cell.getStringCellValue()).append("\t");
                            break;
                        case NUMERIC:
                            excelContent.append(cell.getNumericCellValue()).append("\t");
                            break;
                        case BOOLEAN:
                            excelContent.append(cell.getBooleanCellValue()).append("\t");
                            break;
                        default:
                            excelContent.append("Unknown Type\t");
                    }
                }
                excelContent.append("\n");
            }

            System.out.println(excelContent);

            workbook.close();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
