import java.io.BufferedReader;
import java.io.IOException;

public class TxtReader implements FileReader {
    public void readFile(String filePath) {
        try (BufferedReader br = new BufferedReader(new java.io.FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        TxtReader txtReader = new TxtReader();
        txtReader.readFile("path/to/your/file.txt");
    }
}
