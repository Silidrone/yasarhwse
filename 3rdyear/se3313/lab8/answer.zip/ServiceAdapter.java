public class ServiceAdapter implements FileReader {
    Service s;

    ServiceAdapter(Service s) {
        this.s = s;
    }

    public void readFile(String filePath) {
        s.readDataFile(filePath);
    }
}
