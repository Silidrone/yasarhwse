public interface FileReader {
    void readFile(String filePath);
}
