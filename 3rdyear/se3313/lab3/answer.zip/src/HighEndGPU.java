public class HighEndGPU extends ServerDecorator {
    HighEndGPU(Server server) {
        super(server);
    }

    @Override
    double cost() {
        return 0.022890 + obj.cost();
    }

    @Override
    String getDescription() {
        return obj.getDescription() + ", with HighEndGPU";
    }
}
