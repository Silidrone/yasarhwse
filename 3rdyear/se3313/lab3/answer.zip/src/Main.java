import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Server server;

        Scanner myObj = new Scanner(System.in);
        System.out.println("Select server\n1. BasicCPU\n2. HighEndCPU");
        int choice1 = myObj.nextInt();

        System.out.println("Select gpu\n1. BasicGPU\n2. HighEndGPU");
        int choice2 = myObj.nextInt();

        System.out.println("Select memory\n1. LowMemory\n2. HighMemory");
        int choice3 = myObj.nextInt();

        if(choice1 == 1) {
            server = new BasicCPU();
        } else if (choice1 == 2) {
            server = new HighEndCPU();
        } else {
            System.out.println("Invalid option chosen!");
            return;
        }

        if(choice2 == 1) {
            server = new BasicGPU(server);
        } else if (choice2 == 2) {
            server = new HighEndGPU(server);
        }

        if(choice3 == 1) {
            server = new LowMemory(server);
        } else if(choice3 == 2) {
            server = new HighMemory(server);
        }

        System.out.println("Total Price: $" + server.cost());
        System.out.println("Description: " + server.getDescription());
    }
}