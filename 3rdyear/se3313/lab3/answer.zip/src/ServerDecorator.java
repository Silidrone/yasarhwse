public abstract class ServerDecorator extends Server {
    Server obj;

    ServerDecorator(Server server) {
        this.obj = server;
    }
}
