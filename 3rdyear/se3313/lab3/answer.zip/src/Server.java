// Didn't want to make it an interface since it might contain some state in the future
public abstract class Server {
    abstract double cost();
    abstract String getDescription();
}
