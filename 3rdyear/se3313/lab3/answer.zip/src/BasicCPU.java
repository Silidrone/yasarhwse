public class BasicCPU extends Server {
    @Override
    double cost() {
        return 0.01484;
    }

    @Override
    String getDescription() {
        return "BasicCPU";
    }
}
