public class LowMemory extends ServerDecorator {
    LowMemory(Server server) {
        super(server);
    }

    @Override
    double cost() {
        return 0.000920 + obj.cost();
    }

    @Override
    String getDescription() {
        return obj.getDescription() + ", with LowMemory";
    }
}
