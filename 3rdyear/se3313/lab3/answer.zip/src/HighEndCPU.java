public class HighEndCPU extends Server {
    @Override
    double cost() {
        return 0.049468;
    }

    @Override
    String getDescription() {
        return "HighEndCPU";
    }
}
