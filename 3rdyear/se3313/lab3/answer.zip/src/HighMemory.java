public class HighMemory extends ServerDecorator {
    HighMemory(Server server) {
        super(server);
    }

    @Override
    double cost() {
        return 0.003067 + obj.cost();
    }

    @Override
    String getDescription() {
        return obj.getDescription() + ", with HighMemory";
    }
}
