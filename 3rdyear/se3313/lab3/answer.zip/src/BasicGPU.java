public class BasicGPU extends ServerDecorator {
    BasicGPU(Server server) {
        super(server);
    }

    @Override
    double cost() {
        return 0.006867 + obj.cost();
    }

    @Override
    String getDescription() {
        return obj.getDescription() + ", with BasicGPU";
    }
}
