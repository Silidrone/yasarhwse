This is the 10-armed Testbed introduced in section 2.3 of the textbook. 
The multiarm bandit machine has 10 arms. Pulling an arm generates a stochastic reward
from a Gaussian distribution with unit-variance. When the machine is reset,
the expected values for each action(pulling an arm) are randomly sampled from a normal
distribution. If you are unfamiliar with the 10-armed Testbed please review it
in the textbook before starting this task.